import json
from pathlib import Path

import joblib
import pandas as pd
import streamlit as st
import sys
import os

# Get project root directory
PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)

# Add project root to Python path
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import joblib

MODEL_PATH = os.path.join(
    PROJECT_ROOT,
    "models",
    "model.pkl"
)

model = joblib.load(MODEL_PATH)
