
import json
import warnings

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import (
    GridSearchCV,
    StratifiedKFold,
    cross_validate,
    train_test_split,
)

from src.config import DATA_PATH, MODEL_DIR, REPORT_DIR, RANDOM_STATE
from src.preprocessing import build_pipeline

warnings.filterwarnings("ignore", category=UserWarning)


def load_data(path=DATA_PATH):
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}. Download the Telco churn CSV "
            "and place it in data/raw/."
        )

    df = pd.read_csv(path)

    required = {
        "customerID", "Churn", "tenure", "MonthlyCharges", "TotalCharges"
    }
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")

    df = df.drop(columns=["customerID"])
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    df["Churn"] = df["Churn"].map({"No": 0, "Yes": 1})

    if df["Churn"].isna().any():
        raise ValueError("Unexpected or missing target values in Churn.")

    X = df.drop(columns=["Churn"])
    y = df["Churn"].astype(int)
    return X, y


def main():
    X, y = load_data()

    X_train_val, X_test, y_train_val, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE, stratify=y
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_train_val,
        y_train_val,
        test_size=0.25,
        random_state=RANDOM_STATE,
        stratify=y_train_val,
    )

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)

    candidates = {
        "Logistic Regression": LogisticRegression(
            max_iter=2000, class_weight="balanced", random_state=RANDOM_STATE
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=300,
            class_weight="balanced",
            random_state=RANDOM_STATE,
            n_jobs=-1,
        ),
        "Gradient Boosting": GradientBoostingClassifier(
            random_state=RANDOM_STATE
        ),
    }

    comparison = []
    for name, estimator in candidates.items():
        pipeline = build_pipeline(estimator)
        scores = cross_validate(
            pipeline,
            X_train,
            y_train,
            cv=cv,
            scoring={
                "precision": "precision",
                "recall": "recall",
                "f1": "f1",
                "roc_auc": "roc_auc",
                "pr_auc": "average_precision",
            },
            n_jobs=-1,
        )
        comparison.append(
            {
                "model": name,
                "precision": float(scores["test_precision"].mean()),
                "recall": float(scores["test_recall"].mean()),
                "f1": float(scores["test_f1"].mean()),
                "roc_auc": float(scores["test_roc_auc"].mean()),
                "pr_auc": float(scores["test_pr_auc"].mean()),
            }
        )

    print("\nCross-validation comparison")
    print(pd.DataFrame(comparison).sort_values("roc_auc", ascending=False))

    logistic_pipeline = build_pipeline(
        LogisticRegression(
            max_iter=2000, class_weight="balanced", random_state=RANDOM_STATE
        )
    )
    search = GridSearchCV(
        estimator=logistic_pipeline,
        param_grid={
            "model__C": [0.01, 0.1, 1, 10, 100],
            "model__class_weight": ["balanced", None],
        },
        scoring="roc_auc",
        cv=cv,
        n_jobs=-1,
        refit=True,
    )
    search.fit(X_train, y_train)
    tuned_model = search.best_estimator_

    val_prob = tuned_model.predict_proba(X_val)[:, 1]
    thresholds = np.arange(0.20, 0.81, 0.05)
    threshold_scores = [
        f1_score(y_val, (val_prob >= threshold).astype(int), zero_division=0)
        for threshold in thresholds
    ]
    best_threshold = float(thresholds[int(np.argmax(threshold_scores))])

    # Refit selected configuration on train + validation after threshold selection.
    final_model = search.best_estimator_
    final_model.fit(X_train_val, y_train_val)

    test_prob = final_model.predict_proba(X_test)[:, 1]
    test_pred = (test_prob >= best_threshold).astype(int)

    metrics = {
        "best_params": search.best_params_,
        "best_cv_roc_auc": float(search.best_score_),
        "validation_selected_threshold": best_threshold,
        "test_roc_auc": float(roc_auc_score(y_test, test_prob)),
        "test_pr_auc": float(average_precision_score(y_test, test_prob)),
        "test_precision": float(precision_score(y_test, test_pred, zero_division=0)),
        "test_recall": float(recall_score(y_test, test_pred, zero_division=0)),
        "test_f1": float(f1_score(y_test, test_pred, zero_division=0)),
        "confusion_matrix": confusion_matrix(y_test, test_pred).tolist(),
        "classification_report": classification_report(
            y_test, test_pred, output_dict=True, zero_division=0
        ),
    }

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    joblib.dump(final_model, MODEL_DIR / "churn_pipeline.joblib")
    metadata = {
        "project": "Customer Churn Prediction",
        "model": "Logistic Regression",
        "threshold": best_threshold,
        "target": "Churn",
        "positive_class": "Yes",
        "random_state": RANDOM_STATE,
    }
    with open(MODEL_DIR / "metadata.json", "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    with open(REPORT_DIR / "model_evaluation.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    print("\nBest parameters:", search.best_params_)
    print("Selected threshold:", best_threshold)
    print("\nFinal held-out test metrics:")
    for key in [
        "test_roc_auc", "test_pr_auc", "test_precision", "test_recall", "test_f1"
    ]:
        print(f"{key}: {metrics[key]:.4f}")
    print("\nSaved model and reports.")


if __name__ == "__main__":
    main()
