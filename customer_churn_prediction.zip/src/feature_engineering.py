
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin

class ChurnFeatureEngineer(BaseEstimator, TransformerMixin):
    """Create features using information available at prediction time."""

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X = X.copy()
        X["tenure_years"] = X["tenure"] / 12.0
        X["avg_charge_per_tenure_month"] = np.where(
            X["tenure"] > 0,
            X["TotalCharges"] / X["tenure"],
            np.nan,
        )
        return X
